module CityGame
{
  export class Renderer
  {
    
  }
}
