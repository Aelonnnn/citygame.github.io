module CityGame
{
  export var idGenerator =
  {
    content: 0,
    player: 0,
    board: 0,
    employee: 0
  }
}
