/// <reference path="../lib/pixi.d.ts" />

var eventManager = new PIXI.EventTarget();