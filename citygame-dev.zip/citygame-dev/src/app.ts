module CityGame
{
  export class App
  {
    
  }
}
