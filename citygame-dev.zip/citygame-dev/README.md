Isometric city building game built in typescript with [PIXI.](https://github.com/GoodBoyDigital/pixi.js)

[<img src="http://i.imgur.com/WSr2Eeb.png">](http://giraluna.github.io/citygame)

[Play](http://giraluna.github.io/citygame)
